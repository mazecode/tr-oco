<?php get_header();?>

<div class="container-fluid h-100">
	<div class="row h-100">
		<div class="col-12 h-100 mh-100">
			<div class="jumbotron jumbotron-fluid align-middle">
				<h1 class="display-1 text-center">404</h1>
				<h2 class="display-3 text-center">
					<?php echo __('Page not found', 'wp_ocodesign'); ?>
				</h2>
			</div>
		</div>
	</div>
</div>

<?php get_footer();
